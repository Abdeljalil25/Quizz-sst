# Quiz SST - Serveur Backend

Application de quiz temps reel avec Node.js + Express + Socket.io pour 150+ participants.

## Architecture

```
Backend: Node.js + Express + Socket.io
Frontend: React + TypeScript + Tailwind CSS + Socket.io-client (servi en static)
Stockage: En memoire (suffisant pour un evenement d'une journee)
```

## Prerequis

- Node.js 18+ (recommande: 20 LTS)
- npm ou yarn

## Installation

```bash
# 1. Cloner ou copier le dossier server/
cd server/

# 2. Installer les dependances
npm install

# 3. Build TypeScript
npm run build

# 4. Lancer le serveur
npm start
```

Le serveur demarre sur le port **3001** par defaut (configurable via `PORT=xxxx`).

## Endpoints API

| Route | Description |
|-------|-------------|
| `GET /api/health` | Verification serveur + nombre de participants |
| `GET /api/questions` | Questions sans les reponses correctes (anti-triche) |
| `GET /api/results` | Classement complet des scores |
| `GET /` | Application React (SPA) |

## Evenements Socket.io

### Host (Animateur)

| Evenement | Action |
|-----------|--------|
| `host:start` | Demarrer le compte a rebours |
| `host:next` | Question suivante |
| `host:prev` | Question precedente |
| `host:reveal` | Reveler la reponse |
| `host:leaderboard` | Afficher le classement |
| `host:end` | Terminer le quiz |
| `host:reset` | Reinitialiser tout |

### Participant

| Evenement | Action |
|-----------|--------|
| `participant:register` | S'inscrire (nom, prenom, entreprise, fonction) |
| `participant:answer` | Soumettre une reponse (questionId, selectedAnswers, timeSpent) |
| `participant:getState` | Recuperer l'etat actuel |

### Reponses du serveur

| Evenement | Description |
|-----------|-------------|
| `game:state` | Etat complet du jeu (phase, question, timer, participants, scores) |
| `participant:count` | Nombre de participants connectes |
| `error` | Message d'erreur |

## Deploiement

### Option 1: VPS (DigitalOcean, AWS EC2, etc.)

```bash
# Sur le serveur Ubuntu/Debian
sudo apt update && sudo apt install -y nodejs npm git

# Copier le dossier server/
cd /var/www/quiz-sst/server
npm install
npm run build

# Lancer avec PM2 pour la production
sudo npm install -g pm2
pm2 start dist/index.js --name "quiz-sst"
pm2 save
pm2 startup

# Ouvrir le port 3001 (ou utiliser un reverse proxy Nginx)
sudo ufw allow 3001
```

### Option 2: Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY dist ./dist
COPY public ./public
EXPOSE 3001
CMD ["node", "dist/index.js"]
```

```bash
docker build -t quiz-sst .
docker run -p 3001:3001 quiz-sst
```

### Option 3: Docker Compose

```yaml
version: '3.8'
services:
  quiz-sst:
    build: .
    ports:
      - "3001:3001"
    environment:
      - PORT=3001
    restart: unless-stopped
```

```bash
docker-compose up -d
```

### Option 4: Heroku / Render / Railway / Fly.io

1. Pousser le dossier `server/` sur Git
2. Connecter a Heroku/Render/Railway
3. Definir `npm start` comme commande de demarrage
4. Le port est automatiquement configure

## Configuration Nginx (reverse proxy)

```nginx
server {
    listen 80;
    server_name quiz-sst.example.com;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## Configuration HTTPS (Let's Encrypt)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d quiz-sst.example.com
```

## Variables d'environnement

| Variable | Defaut | Description |
|----------|--------|-------------|
| `PORT` | 3001 | Port du serveur |

## Acces des participants

### Methode 1: QR Code (recommandee)
- Generer un QR code pointant vers `https://votre-domaine.com`
- Les participants scannent et accedent au quiz

### Methode 2: URL directe
- Partager l'URL `https://votre-domaine.com` par email/WhatsApp

### Methode 3: Double diffusion
- Avant l'evenement: URL par email
- Pendant: QR code sur ecran/projecteur

## Ecran Animateur

L'animateur accede a : `https://votre-domaine.com/#/host`

Controles disponibles:
- **Lancer le Quiz** : Demarre le compte a rebours 3-2-1
- **Question suivante** : Passe a la question suivante
- **Reveler** : Montre la reponse correcte et les stats
- **Classement** : Affiche le top 10
- **Terminer** : Ecran final avec podium

## Resultats et Traçabilite

Page resultats: `https://votre-domaine.com/#/results`

- Podium Top 3
- Tableau complet avec toutes les reponses par participant
- Export CSV (bouton telechargement)
- Filtres et tri

## Support

Pour 150 participants simultanes, un VPS avec:
- 1 CPU
- 1 GB RAM
- Connexion internet stable

Est largement suffisant (Socket.io est tres leger).
