import express from 'express';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import path from 'path';
import { GameManager } from './gameManager';
import { ClientToServerEvents, ServerToClientEvents } from './types';

const app = express();
const httpServer = createServer(app);
const io = new SocketIOServer<ClientToServerEvents, ServerToClientEvents>(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

const gameManager = new GameManager();

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files (the built React app)
app.use(express.static(path.join(__dirname, '../../public')));

// API routes
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', participants: gameManager.getParticipantCount() });
});

app.get('/api/questions', (_req, res) => {
  // Return questions without correct answers (for participants)
  const { quizQuestions } = require('./data');
  const safeQuestions = quizQuestions.map((q: any) => ({
    id: q.id,
    question: q.question,
    answers: q.answers,
    multiple: q.multiple,
    timeLimit: q.timeLimit,
  }));
  res.json(safeQuestions);
});

app.get('/api/results', (_req, res) => {
  res.json(gameManager.getSortedScores());
});

// Redirect all routes to index.html (for SPA routing)
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '../../public/index.html'));
});

// Socket.io connection handling
gameManager.setOnStateChange((state) => {
  io.emit('game:state', state);
});

io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);

  // Send current state to new connection
  socket.emit('game:state', gameManager.getGameState());

  // HOST EVENTS
  socket.on('host:start', () => {
    console.log('Host started the game');
    gameManager.startGame();
  });

  socket.on('host:next', () => {
    const currentIndex = gameManager.getGameState().currentQuestionIndex;
    const nextIndex = currentIndex + 1;
    if (nextIndex < gameManager.getGameState().totalQuestions) {
      gameManager.startQuestion(nextIndex);
    } else {
      gameManager.endGame();
    }
  });

  socket.on('host:prev', () => {
    const currentIndex = gameManager.getGameState().currentQuestionIndex;
    if (currentIndex > 0) {
      gameManager.startQuestion(currentIndex - 1);
    }
  });

  socket.on('host:reveal', () => {
    gameManager.revealAnswer();
  });

  socket.on('host:leaderboard', () => {
    gameManager.showLeaderboard();
  });

  socket.on('host:end', () => {
    gameManager.endGame();
  });

  socket.on('host:reset', () => {
    gameManager.resetGame();
  });

  socket.on('host:getState', () => {
    socket.emit('game:state', gameManager.getGameState());
  });

  // PARTICIPANT EVENTS
  socket.on('participant:register', (data) => {
    try {
      const participant = gameManager.registerParticipant(data, socket.id);
      // @ts-ignore - participant:registered not in typed events but used for ack
      socket.emit('participant:registered', { success: true, participant });
      io.emit('participant:count', gameManager.getParticipantCount());
    } catch (error) {
      socket.emit('error', 'Registration failed');
    }
  });

  socket.on('participant:answer', (data) => {
    gameManager.submitAnswer(socket.id, data.questionId, data.selectedAnswers, data.timeSpent);
  });

  socket.on('participant:getState', () => {
    socket.emit('game:state', gameManager.getGameState());
  });

  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`);
    gameManager.removeParticipant(socket.id);
    io.emit('participant:count', gameManager.getParticipantCount());
  });
});

// Start server
const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`🚀 Quiz SST Server running on port ${PORT}`);
  console.log(`📱 Socket.io ready for real-time connections`);
});
