import { Participant, ScoreEntry, QuizAnswer, GameState, Question } from './types';
import { quizQuestions } from './data';

export class GameManager {
  private participants: Map<string, Participant> = new Map();
  private scores: Map<string, ScoreEntry> = new Map();
  private answers: Map<string, Map<number, QuizAnswer>> = new Map(); // participantId -> questionId -> answer
  private gameState: GameState;
  private currentTimer: NodeJS.Timeout | null = null;
  private onStateChange: ((state: GameState) => void) | null = null;

  constructor() {
    this.gameState = {
      phase: 'waiting',
      currentQuestionIndex: 0,
      timeLeft: 0,
      totalQuestions: quizQuestions.length,
      participants: [],
      scores: [],
    };
  }

  setOnStateChange(callback: (state: GameState) => void) {
    this.onStateChange = callback;
  }

  private emitState() {
    this.gameState.participants = this.getParticipantsList();
    this.gameState.scores = this.getSortedScores();
    if (this.onStateChange) {
      this.onStateChange({ ...this.gameState });
    }
  }

  // Participant management
  registerParticipant(data: Omit<Participant, 'id' | 'socketId' | 'joinedAt'>, socketId: string): Participant {
    const existing = this.findParticipantBySocket(socketId);
    if (existing) {
      return existing;
    }

    const participant: Participant = {
      ...data,
      id: `p_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      socketId,
      joinedAt: new Date().toISOString(),
    };

    this.participants.set(participant.id, participant);
    
    // Initialize empty score entry
    this.scores.set(participant.id, {
      participantId: participant.id,
      nom: participant.nom,
      prenom: participant.prenom,
      entreprise: participant.entreprise,
      score: 0,
      maxScore: this.calculateMaxScore(),
      answers: [],
    });

    this.answers.set(participant.id, new Map());
    this.emitState();
    return participant;
  }

  removeParticipant(socketId: string) {
    const participant = this.findParticipantBySocket(socketId);
    if (participant) {
      this.participants.delete(participant.id);
      // Don't delete score to keep results
      this.emitState();
    }
  }

  findParticipantBySocket(socketId: string): Participant | undefined {
    return Array.from(this.participants.values()).find(p => p.socketId === socketId);
  }

  getParticipantCount(): number {
    return this.participants.size;
  }

  getParticipantsList(): Participant[] {
    return Array.from(this.participants.values());
  }

  // Game control
  startGame() {
    this.gameState.phase = 'countdown';
    this.gameState.currentQuestionIndex = 0;
    this.emitState();
  }

  startQuestion(index: number) {
    if (index < 0 || index >= quizQuestions.length) return;
    
    this.gameState.currentQuestionIndex = index;
    this.gameState.phase = 'question';
    this.gameState.timeLeft = quizQuestions[index].timeLimit;
    this.emitState();

    // Start timer
    if (this.currentTimer) clearInterval(this.currentTimer);
    
    this.currentTimer = setInterval(() => {
      this.gameState.timeLeft -= 1;
      if (this.gameState.timeLeft <= 0) {
        if (this.currentTimer) clearInterval(this.currentTimer);
        this.revealAnswer();
      }
      this.emitState();
    }, 1000);
  }

  revealAnswer() {
    if (this.currentTimer) {
      clearInterval(this.currentTimer);
      this.currentTimer = null;
    }
    this.gameState.phase = 'reveal';
    this.gameState.timeLeft = 0;
    this.emitState();
  }

  showLeaderboard() {
    this.gameState.phase = 'leaderboard';
    this.emitState();
  }

  endGame() {
    if (this.currentTimer) {
      clearInterval(this.currentTimer);
      this.currentTimer = null;
    }
    this.gameState.phase = 'final';
    this.emitState();
  }

  resetGame() {
    if (this.currentTimer) {
      clearInterval(this.currentTimer);
      this.currentTimer = null;
    }
    this.participants.clear();
    this.scores.clear();
    this.answers.clear();
    this.gameState = {
      phase: 'waiting',
      currentQuestionIndex: 0,
      timeLeft: 0,
      totalQuestions: quizQuestions.length,
      participants: [],
      scores: [],
    };
    this.emitState();
  }

  // Answer handling
  submitAnswer(socketId: string, questionId: number, selectedAnswers: number[], timeSpent: number) {
    const participant = this.findParticipantBySocket(socketId);
    if (!participant) return;

    const question = quizQuestions.find(q => q.id === questionId);
    if (!question) return;

    // Check if already answered
    const participantAnswers = this.answers.get(participant.id);
    if (participantAnswers?.has(questionId)) return; // Already answered

    // Check correctness
    const isCorrect = this.checkAnswer(question, selectedAnswers);

    const answer: QuizAnswer = {
      questionId,
      selectedAnswers,
      correct: isCorrect,
      timeSpent,
    };

    // Store answer
    if (!this.answers.has(participant.id)) {
      this.answers.set(participant.id, new Map());
    }
    this.answers.get(participant.id)!.set(questionId, answer);

    // Calculate score
    const scoreEntry = this.scores.get(participant.id);
    if (scoreEntry) {
      const questionScore = this.calculateScore(question, selectedAnswers, timeSpent);
      scoreEntry.score += questionScore;
      scoreEntry.answers.push(answer);
    }

    this.emitState();
  }

  private checkAnswer(question: Question, selected: number[]): boolean {
    if (question.multiple) {
      // All correct must be selected, no incorrect selected
      const allCorrect = question.correctAnswers.every(ca => selected.includes(ca));
      const noIncorrect = selected.every(s => question.correctAnswers.includes(s));
      return allCorrect && noIncorrect;
    } else {
      return selected.length === 1 && selected[0] === question.correctAnswers[0];
    }
  }

  private calculateScore(question: Question, selected: number[], timeSpent: number): number {
    if (question.multiple) {
      const allCorrect = question.correctAnswers.every(ca => selected.includes(ca));
      const noIncorrect = selected.every(s => question.correctAnswers.includes(s));
      if (!allCorrect || !noIncorrect) return 0;
    } else {
      if (selected.length !== 1 || selected[0] !== question.correctAnswers[0]) return 0;
    }

    // Base score + time bonus
    const baseScore = 100;
    const maxTime = question.timeLimit;
    const timeBonus = Math.round((1 - timeSpent / maxTime) * 50);
    return baseScore + timeBonus;
  }

  private calculateMaxScore(): number {
    return quizQuestions.length * 150; // 100 base + 50 max bonus
  }

  getSortedScores(): ScoreEntry[] {
    return Array.from(this.scores.values())
      .sort((a, b) => b.score - a.score);
  }

  getCurrentQuestion(): Question | null {
    if (this.gameState.currentQuestionIndex < 0 || 
        this.gameState.currentQuestionIndex >= quizQuestions.length) {
      return null;
    }
    return quizQuestions[this.gameState.currentQuestionIndex];
  }

  getAnswerStats(questionId: number): number[] {
    const question = quizQuestions.find(q => q.id === questionId);
    if (!question) return [];

    const stats = new Array(question.answers.length).fill(0);
    
    for (const [participantId, answers] of this.answers) {
      const answer = answers.get(questionId);
      if (answer) {
        answer.selectedAnswers.forEach(idx => {
          if (idx < stats.length) stats[idx]++;
        });
      }
    }

    return stats;
  }

  getGameState(): GameState {
    return {
      ...this.gameState,
      participants: this.getParticipantsList(),
      scores: this.getSortedScores(),
    };
  }
}
