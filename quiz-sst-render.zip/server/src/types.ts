export interface Participant {
  id: string;
  nom: string;
  prenom: string;
  entreprise: string;
  fonction: string;
  socketId: string;
  joinedAt: string;
}

export interface QuizAnswer {
  questionId: number;
  selectedAnswers: number[];
  correct: boolean;
  timeSpent: number;
}

export interface ScoreEntry {
  participantId: string;
  nom: string;
  prenom: string;
  entreprise: string;
  score: number;
  maxScore: number;
  answers: QuizAnswer[];
}

export interface Question {
  id: number;
  question: string;
  answers: string[];
  correctAnswers: number[];
  multiple: boolean;
  timeLimit: number;
}

export interface GameState {
  phase: 'waiting' | 'countdown' | 'question' | 'reveal' | 'leaderboard' | 'final';
  currentQuestionIndex: number;
  timeLeft: number;
  totalQuestions: number;
  participants: Participant[];
  scores: ScoreEntry[];
}

// Socket.io event types
export interface ServerToClientEvents {
  'game:state': (state: GameState) => void;
  'participant:joined': (participant: Participant) => void;
  'participant:left': (participantId: string) => void;
  'participant:count': (count: number) => void;
  'participant:registered': (data: { success: boolean; participant: Participant }) => void;
  'question:start': (data: { questionIndex: number; timeLimit: number }) => void;
  'question:reveal': (data: { correctAnswers: number[]; stats: number[] }) => void;
  'question:leaderboard': (scores: ScoreEntry[]) => void;
  'quiz:final': (scores: ScoreEntry[]) => void;
  'quiz:ended': () => void;
  'error': (message: string) => void;
}

export interface ClientToServerEvents {
  'host:start': () => void;
  'host:next': () => void;
  'host:prev': () => void;
  'host:reveal': () => void;
  'host:leaderboard': () => void;
  'host:end': () => void;
  'host:reset': () => void;
  'participant:register': (data: { nom: string; prenom: string; entreprise: string; fonction: string }) => void;
  'participant:answer': (data: { questionId: number; selectedAnswers: number[]; timeSpent: number }) => void;
  'participant:getState': () => void;
  'host:getState': () => void;
}
