# Guide de Deploiement - Quiz SST

## Methode recommandee : Render.com (GRATUIT)

Render.com heberge gratuitement votre backend Node.js + frontend. 150 participants simultanes sont supportes.

---

## ETAPE 1 : Creer un compte Render.com (2 minutes)

1. Allez sur https://render.com
2. Cliquez **"Get Started for Free"**
3. Inscrivez-vous avec votre email ou GitHub/Google
4. Validez votre email

---

## ETAPE 2 : Publier le code sur GitHub (5 minutes)

### Option A - Si vous avez deja un compte GitHub :

1. Allez sur https://github.com/new
2. Nom du repo : `quiz-sst`
3. Visibilite : **Public**
4. Cochez **"Add a README file"**
5. Cliquez **"Create repository"**

6. Sur votre ordinateur, telechargez le fichier `quiz-sst-render.zip`
7. Extrayez le ZIP
8. Ouvrez un terminal dans le dossier `server/`

9. Executez ces commandes :
```bash
cd server/
git init
git add .
git commit -m "Quiz SST - Journee Securite"
git branch -M main
git remote add origin https://github.com/VOTRE_USERNAME/quiz-sst.git
git push -u origin main
```

### Option B - Si vous n'avez pas GitHub :

1. Creez un compte sur https://github.com (gratuit)
2. Suivez les etapes de l'Option A

---

## ETAPE 3 : Deployer sur Render.com (5 minutes)

1. Dans Render.com, cliquez **"New +"** en haut a droite
2. Selectionnez **"Web Service"**
3. Connectez votre compte GitHub
4. Selectionnez le repository `quiz-sst`
5. Remplissez le formulaire :

| Champ | Valeur |
|-------|--------|
| Name | `quiz-sst` |
| Runtime | `Node` |
| Build Command | `npm install && npm run build` |
| Start Command | `npm start` |
| Plan | **Free** |

6. Dans **Advanced**, ajoutez une variable d'environnement :
   - Key : `PORT`
   - Value : `10000`

7. Cliquez **"Create Web Service"**

8. Render va automatiquement :
   - Telecharger votre code
   - Installer les dependances
   - Compiler TypeScript
   - Deployer le serveur

9. Attendez 2-3 minutes (vous voyez les logs en direct)

10. Quand vous voyez **"Your service is live"**, copiez l'URL :
    `https://quiz-sst-XXXX.onrender.com`

---

## ETAPE 4 : Generer le QR Code (2 minutes)

1. Ouvrez votre navigateur
2. Allez sur https://www.qr-code-generator.com/ (gratuit)
3. Entrez votre URL Render : `https://quiz-sst-XXXX.onrender.com`
4. Cliquez **"Generate QR Code"**
5. Telechargez l'image PNG

**Ou bien** utilisez directement l'URL dans votre presentation PowerPoint.

---

## ETAPE 5 : Tester avant le Jour J (5 minutes)

### Test 1 - Verifier que le serveur repond
```
https://quiz-sst-XXXX.onrender.com/api/health
```
Vous devriez voir : `{"status":"ok","participants":0}`

### Test 2 - Ouvrir l'ecran animateur
```
https://quiz-sst-XXXX.onrender.com/#/host
```
Vous devez voir "25 participants" et les boutons de controle.

### Test 3 - Simuler un participant
1. Ouvrez votre telephone ou un autre onglet
2. Allez sur `https://quiz-sst-XXXX.onrender.com`
3. Remplissez le formulaire d'inscription
4. Verifiez que le compteur sur /host augmente a 26

### Test 4 - Lancer une question
1. Sur /host, cliquez **"Lancer le Quiz"**
2. Sur le telephone, vous devez voir la premiere question apparaitre
3. Repondez sur le telephone
4. Sur /host, cliquez **"Reveler"** puis **"Suivante"**

---

## URLs importantes apres deploiement

| Page | URL | Usage |
|------|-----|-------|
| **Accueil / QR Code** | `https://quiz-sst-XXXX.onrender.com` | Page a scanner |
| **Ecran Animateur** | `.../#/host` | Projecteur, controle du quiz |
| **Quiz Participant** | `.../#/register` | Inscription + questions |
| **Resultats + CSV** | `.../#/results` | Traçabilite + export |

---

## Deroulement le Jour J

| Heure | Action |
|-------|--------|
| H-30 | Verifier que le serveur est en ligne (`/api/health`) |
| H-15 | Afficher la page d'accueil avec le QR code sur le projecteur |
| H | Les participants scannent et s'inscrivent |
| H+5 | Vous voyez 150 participants sur /host |
| H+10 | **"Lancer le Quiz"** → 3-2-1 → Question 1 |
| | Les participants repondent sur leur telephone |
| | **"Reveler"** → montre la bonne reponse |
| | **"Suivante"** → Question 2 |
| | Repeter pour les 11 questions |
| Fin | **"Terminer"** → Podium → /results → Export CSV |

---

## Limitations du plan gratuit Render.com

| Limite | Detail |
|--------|--------|
| **Spin down** | Le serveur s'endort apres 15 min d'inactivite |
| **Demarrage** | 30-60 secondes pour se reveiller |
| **Bande passante** | 100 GB/mois (suffisant pour 150 participants) |
| **Disponibilite** | 99.9% |

### Astuce anti-spin-down
Avant l'evenement, faites un appel a `/api/health` toutes les 10 minutes :
```bash
# Sur votre ordinateur, ouvrez un terminal et laissez tourner :
while true; do curl https://quiz-sst-XXXX.onrender.com/api/health; echo; sleep 600; done
```
Ou utilisez https://cron-job.org (gratuit) pour pinger toutes les 10 minutes.

---

## Methode alternative : Docker (si vous avez un serveur)

Si vous avez deja un serveur VPS (DigitalOcean, Hetzner, etc.) :

```bash
# 1. Installer Docker
curl -fsSL https://get.docker.com | sh

# 2. Copier le dossier server/ sur votre VPS (via SCP ou Git)
# 3. cd server/

# 4. Lancer avec Docker Compose
docker-compose up -d

# 5. Verifier
curl http://localhost:3001/api/health
```

Le serveur tourne sur le port 3001. Configurez votre firewall :
```bash
ufw allow 3001
```

---

## Problemes courants

### "Cannot connect to server" sur le telephone
- Verifiez que l'URL commence bien par **https://**
- Essayez avec un autre navigateur (Chrome recommande)
- Desactivez le VPN si vous en utilisez un

### Le compteur de participants ne bouge pas
- Verifiez que le participant va bien sur l'URL du serveur (pas l'ancienne URL)
- Ouvrez la console developpeur (F12) et verifiez les erreurs

### "Service is starting" pendant longtemps sur Render
- C'est normal pour le plan gratuit (30-60 secondes)
- Rafraichissez la page apres 1 minute

### Le serveur s'arrete pendant l'evenement
- Le plan gratuit ne s'arrete pas si des gens sont connectes
- Il ne s'endort que si personne ne parle au serveur pendant 15 min
- Pendant le quiz, tout le monde envoie des messages toutes les secondes

---

## Support

Si vous bloquez :
1. Verifiez les logs sur Render.com (onglet "Logs")
2. Verifiez que `npm run build` fonctionne en local
3. Verifiez que `npm start` fonctionne en local
